from __future__ import annotations

"""Database access layer.

This module models three production-grade concerns:

1) **Read/write routing**: writes always go to a primary; reads can route to
   replicas when they are sufficiently caught up.
2) **Logical sharding for retrieval**: retrieval fan-out can target multiple
   "shard" DSNs (separate Postgres clusters) and merge results.
3) **Health/lag checks**: replicas can be excluded from read routing if their
   replay lag exceeds a configured threshold.

The code is intentionally lightweight (no external orchestrator dependency)
while still demonstrating platform design intent.
"""

from contextlib import contextmanager
from dataclasses import dataclass
from typing import Dict, Iterable, Optional

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from app.core.config import settings


_engine_cache: Dict[str, tuple] = {}


def _get_sessionmaker(database_url: str) -> sessionmaker:
    cached = _engine_cache.get(database_url)
    if cached:
        return cached[1]

    engine = create_engine(database_url, pool_pre_ping=True)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    _engine_cache[database_url] = (engine, SessionLocal)
    return SessionLocal


def _primary_url() -> str:
    return settings.primary_database_url or settings.database_url


def _replica_urls_for_region(region: str | None = None) -> list[str]:
    """Parse replica URLs.

    Supports two styles:
      - replica_database_urls: comma-separated list
      - replica_regions: 'eu:dsn1|dsn2;us:dsn3'
    """

    region = (region or settings.region or "").strip()

    if settings.replica_regions:
        mapping = {}
        for part in settings.replica_regions.split(";"):
            part = part.strip()
            if not part:
                continue
            key, _, val = part.partition(":")
            mapping[key.strip()] = [v.strip() for v in val.split("|") if v.strip()]
        if region and region in mapping:
            return mapping[region]
        # Fallback: any region
        for urls in mapping.values():
            if urls:
                return urls

    if not settings.replica_database_urls:
        return []
    return [u.strip() for u in settings.replica_database_urls.split(",") if u.strip()]


def _replica_replay_lag_seconds(database_url: str) -> float:
    """Return estimated replay lag in seconds for a replica.

    Uses pg_last_xact_replay_timestamp(). On primaries this can be NULL, and on
    non-replica Postgres it returns NULL; in that case we treat lag as 0.

    Note: This is intentionally a simple signal. In production you might also
    check WAL byte lag and connection pool saturation.
    """

    Session = _get_sessionmaker(database_url)
    db = Session()
    try:
        # NULL on primary; NULL if no replay timestamp.
        row = db.execute(
            text(
                """
                SELECT EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp()))
                """
            )
        ).fetchone()
        if not row or row[0] is None:
            return 0.0
        return float(row[0])
    finally:
        db.close()


def choose_read_url(region: str | None = None) -> str:
    """Choose the best read target (replica if healthy, else primary)."""

    replicas = _replica_urls_for_region(region)
    if not replicas:
        return _primary_url()

    threshold = float(settings.max_replica_lag_seconds)
    candidates: list[tuple[str, float]] = []
    for r in replicas:
        try:
            lag = _replica_replay_lag_seconds(r)
            candidates.append((r, lag))
        except Exception:
            # Treat failing replicas as unhealthy
            continue

    if not candidates:
        return _primary_url()

    # Pick lowest lag replica under threshold; otherwise fall back to primary.
    candidates.sort(key=lambda x: x[1])
    best_url, best_lag = candidates[0]
    if best_lag <= threshold:
        return best_url
    return _primary_url()


@dataclass(frozen=True)
class DBTarget:
    url: str
    role: str  # "read" | "write" | "shard"


def iter_retrieval_shards() -> Iterable[DBTarget]:
    dsns = [d.strip() for d in settings.retrieval_shard_dsns.split(",") if d.strip()]
    if not dsns:
        # Single-cluster mode
        yield DBTarget(url=choose_read_url(), role="read")
        return

    for dsn in dsns:
        yield DBTarget(url=dsn, role="shard")


@contextmanager
def session_scope(database_url: str):
    """Provide a transactional scope around operations."""

    Session = _get_sessionmaker(database_url)
    db = Session()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


@contextmanager
def write_session_scope():
    """Write session bound to the primary."""
    with session_scope(_primary_url()) as db:
        yield db


@contextmanager
def read_session_scope(region: Optional[str] = None):
    """Read session routed to a healthy replica when possible."""
    with session_scope(choose_read_url(region)) as db:
        yield db
