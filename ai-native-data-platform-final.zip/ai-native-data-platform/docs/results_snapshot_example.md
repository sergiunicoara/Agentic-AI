### Results Snapshot (baseline)

✅ gates passed

| Metric | Value |
|---|---|
| Pass rate | 0.850 |
| Recall@k (mean) | 0.780 |
| MRR (mean) | 0.455 |
| Latency p95 (ms) | 620 |
| Unknown rate | 0.070 |
| Gen failure rate | 0.010 |

> This file is an example. CI generates a fresh snapshot at `artifacts/results_snapshot.md` and uploads it as a workflow artifact.
