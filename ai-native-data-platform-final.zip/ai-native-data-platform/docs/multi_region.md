# Multi-region deployment story

This repository includes a reference multi-region architecture for an AI-native
data platform.

## Goals
...
