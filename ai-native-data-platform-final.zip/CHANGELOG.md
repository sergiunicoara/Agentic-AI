# CHANGELOG

## Platform Reliability & Retrieval Upgrade

### Fixed
- Groundedness verifier schema mismatch: now supports both `{id, text}` and legacy `{chunk_id, chunk_text}` formats.
- Retrieval cache invalidation bug: cache keys now include `index_epoch` to prevent stale reads after reindexing.
- Embedding version drift in rerankers: rerankers now use the embedding version stamped by retrievers.

### Added
- Online enforcement of groundedness in the reliability contract with safe degradation to `unknown=true`.
- In-process LLM circuit breaker with configurable failure threshold and cooldown.
- Transient-only retry policy for LLM provider calls.
- Cross-encoder-style stub reranker (`rerank_mode: cross`) combining semantic and lexical scoring.
- Model-safe query embedding cache keys including provider/model/dimension metadata.

### Improved
- Consistent propagation of embedding version metadata through retrieval pipelines.
- Reliability metrics coverage for groundedness violations.
- Configuration hooks for reranker behavior and circuit breaker tuning.

